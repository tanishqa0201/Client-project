
package arihanttransformer;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import spr.dao.LogicDao;
import spr.dto.Transformer;




public class ArihantTransformer {

    
    public static void main(String[] args)
    {
         ApplicationContext context=new ClassPathXmlApplicationContext("/SpringXmlConfig.xml");
       
          LogicDao  dao=(LogicDao)context.getBean("technosoft"); 
          
          
          
          
           int PRESS=0;
    
    
    Scanner scanner=new Scanner(System.in);

        System.out.println("PLEASE SELECT THE USER...");
        System.out.println("1.Admin ");
        System.out.println("2. Client");
            byte choice=scanner.nextByte();
            switch(choice)
            {
                case 1:
                    System.out.println("ENTER ID AND PASSWORD TO CONTINUE");
                    String userId=scanner.next();
                    String password=scanner.next();
                    boolean finalOutput=dao.signIn(userId, password);
                    if(finalOutput)
                    {

do
{
                                                    
                        
                        
        System.out.println("--------INDEX----------");
        System.out.println("SELECT THE CHOCIE TO CONT...");
        System.out.println("1.ADD RECORD\n"
                + "2.DELETE RECORD\n"
                + "3.UPDATE RECORD\n"
                + "4.SEARCH RECORD\n"
                + "5.SHOWALL RECORD\n"
                + "6.EXIT");
        System.out.println("7.CHANGE PASSWORD");
        byte menuChoice=scanner.nextByte();
        switch(menuChoice)
        {       
            case 1:
                System.out.println("Enter the Transformr Id:");
                 int tId=scanner.nextInt();
                 System.out.println("Enter the type of the Transformer:");
                 String type=scanner.next();
                 System.out.println("Enter the Model of the Transformer:");
                 String model=scanner.next();
                 System.out.println("Description of the Transformer:");
                 String description=scanner.next();
                 System.out.println("Price of the Transformer: ");
                 int price=scanner.nextInt();
                 System.out.println("Enter the Efficiency of the Transformer:");
                 String efficiency=scanner.next();
                 System.out.println("Voltage of the Transformer: ");
                 String voltage=scanner.next();
                 System.out.println("Enter the Manufacture Date:");
                 String manufactureDate=scanner.next();
                  
                 System.out.println("Enter the Material Used Date:");
                 String materialUsed=scanner.next();
                Transformer ref=new Transformer(tId,type,model,description,price,efficiency,voltage,manufactureDate,materialUsed);
                dao.insert(ref);
                break;
            case 2:
                System.out.println("enter the Id:");
                 tId=scanner.nextInt();
                dao.delete(tId);
                break;
                case 3:
                 System.out.println("enter the Id:");
                 tId=scanner.nextInt();
                dao.update(tId);
                break;
                case 4:
                System.out.println("enter the Id:");
                 tId=scanner.nextInt();
                dao.search(tId);
                break;
                case 5:
                    dao.showAll();
                    break;
                case 6:
                    System.exit(0);
                    break;
                case 7:
                    System.out.println("ENTER OLD and NEW PASSWORD");
                     userId=scanner.next();
                     password=scanner.next();
                    finalOutput=dao.signIn(userId, password);
                    if(finalOutput)
                    {
                        System.out.println("ENTER NEW PASSWORD");
                        String newPassword=scanner.next();
                        dao.changePassword(userId,newPassword);
                        System.out.println("...PASSWORD CHANGED...");
                    }
                    else
                    {
                        System.out.println("INVALID OLD ID/PASSWORD");
                    }
                    break;
                default:
                    System.out.println("INVALID CHOICE");
        }

    
    System.out.println("PRESS 1 TO RELOAD THE MENU...");
     PRESS=scanner.nextInt();
}

while(PRESS==1);
                    }
                    else
                    {
                        System.out.println("INVALID ID/PASSWORD.... TRY AGAIN...GOOD LUCK");
                    }
                    break ;
                    case 2:
                        System.out.println("UNDER CONSTRUCTION...");
                    break ;
                    default:
                        System.exit(0);
            }

        
            

        

    }
          
          
          
          
    
    
}
