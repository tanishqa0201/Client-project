
package spr.dto;


public class Transformer {
    
    private int tId;
    private String type;
    private String model;
    private String description;
    private int price;
    private String efficiency;
    private String voltage;
    private String manufactureDate;
    private String materialUsed;
    
   public Transformer(){}
   
   public Transformer(int tId, String type, String model,String description,int price,
                       String efficiency,String voltage,String manufactureDate,String materialUsed)
   {
    this.tId=tId;
    this.type=type;
    this.model=model;
    this.description=description;
    this.price=price;
    this.efficiency=efficiency;
    this.voltage=voltage;
    this.manufactureDate=manufactureDate;
    this.materialUsed=materialUsed;
   
   }

  

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(String efficiency) {
        this.efficiency = efficiency;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public String getManufactureDate() {
        return manufactureDate;
    }

    public void setManufactureDate(String manufactureDate) {
        this.manufactureDate = manufactureDate;
    }

    public String getMaterialUsed() {
        return materialUsed;
    }

    public void setMaterialUsed(String materialUsed) {
        this.materialUsed = materialUsed;
    }

    public int gettId() {
        return tId;
    }

    public void settId(int tId) {
        this.tId = tId;
    }
   
    
    
}
