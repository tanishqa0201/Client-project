
package spr.dao;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import spr.dto.Transformer;
import spr.dto.User;


public class LogicDao {
    
    
    
    private HibernateTemplate template;
    
    public HibernateTemplate getTemplate(){
    return template;
    }
    
    public void setTemplate(HibernateTemplate template){
    this.template=template;
    }
    
    public boolean signIn(String userId, String password)
    {
     List<User> result=template.find("from User where userId=? and password=?",userId,password);
     if(result.isEmpty())
     return false;
     return true;
    }
    
    public void insert(Transformer ref)
    {
        template.save(ref);
    }
    
    public void delete(int tId)
    {
        template.execute(new HibernateCallback<Object>(){
        @Override
        public Object doInHibernate(org.hibernate.Session session)throws org.hibernate.HibernateException, SQLException 
        {
            Transformer obj=
                    (Transformer)session.get(Transformer.class,tId);
            if(obj==null)
            {
             System.out.println("no record Found");
             
            }
            else{
             session.delete(obj);
            }
            return null;
        }
        });
    }
    
    public void update(int tId)
    {
        template.execute(new HibernateCallback<Object>()
        {
          @Override
          public Object doInHibernate(org.hibernate.Session session)throws org.hibernate.HibernateException, SQLException 
                  {
                      Transformer obj=
                      (Transformer)session.get(Transformer.class, tId);
                      if(obj==null)
                      {
                       System.out.println("no Record found");
                      }
                      else
                      {
                           System.out.println("---MENU-----");
                           System.out.println("1.Transformer Type:");
                           System.out.println("2.Transformer Model:");
                           System.out.println("3.Transformer Description:");
                           System.out.println("4.Transformer Price:");
                           System.out.println("5.Transformer Efficiency:");
                           System.out.println("6.Transformer Voltage:");
                           
                           System.out.println("select the choice");
                           
                 Scanner sc=new Scanner(System.in);
                 int ch=sc.nextInt();
                 switch(ch)
                     
                 {
                 
                     case 1:
                         System.out.println("Updated Type Of Transformer:");
                         String type=sc.next();
                         obj.setType(type);
                         session.update(obj);
                         break;
                         
                         
                     case 2:
                         System.out.println("Updated Moel of Transformer:");
                         String model=sc.next();
                         obj.setModel(model);
                         session.update(obj);
                         break;
                         
                     case 3:
                         System.out.println("Updated Description Of Transformer:");
                         String description=sc.next();
                         obj.setDescription(description);
                         session.update(obj);
                         break;
                         
                    case 4:
                         System.out.println("Updated Price Of Transformer:");
                         int price=sc.nextInt();
                         obj.setPrice(price);
                         session.update(obj);
                         break;
                    case 5:
                         System.out.println("Updated Efficiency Of Transformer:");
                         String efficiency=sc.next();
                         obj.setEfficiency(efficiency);
                         session.update(obj);
                         break;
                         
                         case 6:
                         System.out.println("Updated Voltage Of Transformer:");
                         String voltage=sc.next();
                         obj.setVoltage(voltage);
                         session.update(obj);
                         break;
                         
                         
                       
                         
                       
                     default:
                         System.out.println("INVALID CHOICE");
                 
                 }
                      }
                      return null;
                  }
        });
    }
    
    
    
      public void  search(int tId)
    {
     template.execute(new HibernateCallback<Object>() {
     @Override
     public Object doInHibernate(org.hibernate.Session session) throws org.hibernate.HibernateException, SQLException 
        {
            Transformer obj=
            (Transformer)session.get(Transformer.class,tId);
             if(obj==null)
            {
                System.out.println("NO RECORD FOUND");
            }
    else
    {
     System.out.println(obj.getType()+" "+obj.getModel()+"  "+obj.getDescription()+"  "+obj.getPrice()+" "+
      obj.getEfficiency()+" "+obj.getVoltage()+" "+obj.getManufactureDate()+" "+obj.getMaterialUsed());
    }
      return null;
  }
});
    }
      
      
public void showAll()
 {
  template.execute(new HibernateCallback<Object>() 
   {
    @Override
     public Object doInHibernate(Session session) throws HibernateException, SQLException 
      {
            Criteria crit=session.createCriteria(Transformer.class);
            List<Transformer> data=crit.list();
             if(data.isEmpty())
                    {
                      System.out.println("NO RECORD TO FOUND DISPLAY");
                    }
else
{
    for(Transformer obj: data)
    {
       System.out.println(obj.getType()+" "+obj.getModel()+"  "+obj.getDescription()+"  "+obj.getPrice()+" "+
      obj.getEfficiency()+" "+obj.getVoltage()+" "+obj.getManufactureDate()+" "+obj.getMaterialUsed());
    }
}
return null;
            }
        });
    }


  public void changePassword(String uId,String newPass)
   {
       template.execute(new HibernateCallback<Object>() 
       {
           @Override
           public Object doInHibernate(Session session) throws HibernateException, SQLException 
           {
               User user=(User)session.get(User.class,uId);
               user.setPassword(newPass);
               session.update(user);
                         return null;
           }
 
       });
   }
    
    
}
